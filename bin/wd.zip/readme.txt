
  Usage of Open Watcom's WD for 16-bit Assembly

  1. About WD

  WD allows symbolic debugging of DOS programs, if the compiler/assembler
  and linker is able to produce Codeview debugging information. WD
  understands more formats, but these aren't relevant here.

  2. Installation

  Just copy all files contained in this package to a directory. This
  directory must be contained in the PATH environment variable when WD is
  launched. If this isn't feasible, you'll have to copy the application 
  thas is to be debugged into the directory where WD resides.

  3. Modifications

  This version of WD is not quite the standard one that one receives when
  downloading the DOS version of Open Watcom. A few files have been modified;
  in detail:

  a) MADX86.MAD: the modification in this file enables a page swap in "trace"
     mode whenever an INT instruction is detected.

  b) STD.TRP: extended to allow to view and edit the XMM registers.

  c) DEFAULT.DBG: has been modified to initially show the register window on 
     the upper right corner - quite appropriate for assembly programs.

  d) CODEVIEW.DIP: may have caused a crash when debugging OW C modules.

  4. Usage

  Sample DOS2.asm is provided, to make the interested audience aware
  of a few quirks of WD and how to avoid the unexpected results that
  they may cause. File MAKEDOS2.BAT shows how to create DOS2.EXE,
  including codeview symbolic debugging info.

  Once DOS2.EXE is created, just start WD with:
  
  WD DOS2.EXE

  and the debugger will stop at the 'main' procedure.

  It should be mentioned that the help file WD.HLP, which is contained
  in this package, is a Windows help file - and hence no help can
  be displayed from inside the debugger.

  japheth
